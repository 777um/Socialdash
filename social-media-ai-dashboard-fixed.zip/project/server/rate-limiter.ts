/**
 * RATE LIMITER — Redis-backed
 * Resolve P0: estado em Map() que não sobrevive a reinicializações ou escala horizontal.
 * Usa INCR + EXPIRE atômico; fail-open se Redis indisponível.
 */

import { getRedisClient } from './redis-client';

export interface RateLimiterConfig {
  windowMs: number;
  maxRequests: number;
}

const DEFAULT_CONFIG: RateLimiterConfig = { windowMs: 60_000, maxRequests: 100 };

export function createRateLimiter(config: Partial<RateLimiterConfig> = {}) {
  const { windowMs, maxRequests } = { ...DEFAULT_CONFIG, ...config };
  const windowSecs = Math.ceil(windowMs / 1000);
  const prefix = 'rl:custom:';

  return {
    /** Retorna true se dentro do limite, false se excedeu */
    check: async (key: string): Promise<boolean> => {
      try {
        const redis = getRedisClient();
        const rkey = `${prefix}${key}`;
        const count = await redis.incr(rkey);
        if (count === 1) await redis.expire(rkey, windowSecs);
        return count <= maxRequests;
      } catch {
        return true; // fail-open
      }
    },

    reset: async (key: string): Promise<void> => {
      try { await getRedisClient().del(`${prefix}${key}`); } catch { /* ignore */ }
    },

    getStatus: async (key: string): Promise<{ remaining: number; resetTime: number }> => {
      try {
        const redis = getRedisClient();
        const rkey = `${prefix}${key}`;
        const [rawCount, ttl] = await Promise.all([redis.get(rkey), redis.ttl(rkey)]);
        const count = parseInt(rawCount || '0', 10);
        return {
          remaining: Math.max(0, maxRequests - count),
          resetTime: Date.now() + (ttl > 0 ? ttl * 1000 : windowMs),
        };
      } catch {
        return { remaining: maxRequests, resetTime: Date.now() + windowMs };
      }
    },

    /** No-op: Redis TTL limpa automaticamente */
    cleanup: async (): Promise<void> => { /* no-op */ },
  };
}

// Rate limiters específicos
export const notificationRateLimiter = createRateLimiter({ windowMs: 60_000, maxRequests: 50 });
export const webhookRateLimiter      = createRateLimiter({ windowMs: 60_000, maxRequests: 100 });
export const jobRateLimiter          = createRateLimiter({ windowMs: 60_000, maxRequests: 30 });

/** Verificar rate limit — lança erro tipado se excedido */
export async function checkRateLimit(
  limiter: ReturnType<typeof createRateLimiter>,
  key: string
): Promise<void> {
  const allowed = await limiter.check(key);
  if (!allowed) {
    const status = await limiter.getStatus(key);
    const error: any = new Error('Rate limit exceeded');
    error.statusCode = 429;
    error.retryAfter = Math.ceil((status.resetTime - Date.now()) / 1000);
    throw error;
  }
}
